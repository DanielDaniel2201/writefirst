"use strict";
(() => {
  // src/shared/settings.ts
  var IDLE_DELAY_MIN_MS = 800;
  var IDLE_DELAY_MAX_MS = 1500;
  var IDLE_DELAY_STEP_MS = 100;
  var DEFAULT_SETTINGS = {
    enabled: true,
    sourceLanguage: "Chinese",
    targetLanguage: "English",
    providerMode: "openai-compatible",
    baseUrl: "https://api.openai.com/v1",
    model: "gpt-4o-mini",
    apiKey: "",
    idleMs: 800,
    minChars: 2
  };
  function normalizeSettings(value) {
    const settings = { ...DEFAULT_SETTINGS, ...value };
    return {
      ...settings,
      enabled: Boolean(settings.enabled),
      sourceLanguage: nonEmpty(settings.sourceLanguage, DEFAULT_SETTINGS.sourceLanguage),
      targetLanguage: nonEmpty(settings.targetLanguage, DEFAULT_SETTINGS.targetLanguage),
      providerMode: "openai-compatible",
      baseUrl: trimTrailingSlash(nonEmpty(settings.baseUrl, DEFAULT_SETTINGS.baseUrl)),
      model: nonEmpty(settings.model, DEFAULT_SETTINGS.model),
      apiKey: settings.apiKey?.trim() ?? "",
      idleMs: normalizeIdleMs(settings.idleMs),
      minChars: Math.max(1, Number(settings.minChars) || DEFAULT_SETTINGS.minChars)
    };
  }
  async function getSettings() {
    const value = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    return normalizeSettings(value);
  }
  async function saveSettings(settings) {
    await chrome.storage.sync.set(normalizeSettings(settings));
  }
  function nonEmpty(value, fallback) {
    const trimmed = value?.trim();
    return trimmed ? trimmed : fallback;
  }
  function trimTrailingSlash(value) {
    return value.replace(/\/+$/, "");
  }
  function normalizeIdleMs(value) {
    const numeric = Number(value) || DEFAULT_SETTINGS.idleMs;
    const clamped = Math.min(IDLE_DELAY_MAX_MS, Math.max(IDLE_DELAY_MIN_MS, numeric));
    return Math.round(clamped / IDLE_DELAY_STEP_MS) * IDLE_DELAY_STEP_MS;
  }

  // src/popup.ts
  var form = document.getElementById("settings-form");
  var enabled = document.getElementById("enabled");
  var sourceLanguage = document.getElementById("sourceLanguage");
  var targetLanguage = document.getElementById("targetLanguage");
  var idleDelay = document.getElementById("idleDelay");
  var idleDelayValue = document.getElementById("idleDelayValue");
  var baseUrl = document.getElementById("baseUrl");
  var model = document.getElementById("model");
  var apiKey = document.getElementById("apiKey");
  var status = document.getElementById("status");
  idleDelay.min = String(IDLE_DELAY_MIN_MS);
  idleDelay.max = String(IDLE_DELAY_MAX_MS);
  idleDelay.step = String(IDLE_DELAY_STEP_MS);
  void hydrate();
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    void persist();
  });
  enabled.addEventListener("change", () => {
    void persist("Saved.");
  });
  idleDelay.addEventListener("input", () => {
    updateIdleDelayValue(Number(idleDelay.value));
  });
  idleDelay.addEventListener("change", () => {
    void persist("Saved.");
  });
  async function hydrate() {
    applySettings(await getSettings());
  }
  async function persist(message = "Settings saved.") {
    const settings = normalizeSettings({
      ...DEFAULT_SETTINGS,
      enabled: enabled.checked,
      sourceLanguage: sourceLanguage.value,
      targetLanguage: targetLanguage.value,
      idleMs: Number(idleDelay.value),
      baseUrl: baseUrl.value,
      model: model.value,
      apiKey: apiKey.value
    });
    await saveSettings(settings);
    applySettings(settings);
    setStatus(message);
  }
  function applySettings(settings) {
    enabled.checked = settings.enabled;
    sourceLanguage.value = settings.sourceLanguage;
    targetLanguage.value = settings.targetLanguage;
    idleDelay.value = String(settings.idleMs);
    updateIdleDelayValue(settings.idleMs);
    baseUrl.value = settings.baseUrl;
    model.value = settings.model;
    apiKey.value = settings.apiKey;
  }
  function updateIdleDelayValue(valueMs) {
    idleDelayValue.value = `${(valueMs / 1e3).toFixed(1)}s`;
  }
  function setStatus(message) {
    status.textContent = message;
    window.setTimeout(() => {
      if (status.textContent === message) {
        status.textContent = "";
      }
    }, 1800);
  }
})();
//# sourceMappingURL=popup.js.map
