"use strict";
(() => {
  // src/content/card.ts
  var HOST_ID = "write-first-translation-card-host";
  var CARD_GAP = 6;
  var FLIP_ABOVE_SPACE_THRESHOLD = 120;
  var FALLBACK_CARD_HEIGHT = 72;
  var MIN_CARD_HEIGHT = 32;
  var MAX_CARD_HEIGHT = 220;
  var MAX_CARD_WIDTH = 520;
  var VIEWPORT_PADDING = 12;
  var CARD_HORIZONTAL_PADDING = 24;
  var CARD_HORIZONTAL_BORDER = 2;
  var APPROX_ASCII_CHAR_WIDTH = 7.2;
  var APPROX_SPACE_CHAR_WIDTH = 3.6;
  var APPROX_WIDE_CHAR_WIDTH = 13;
  var SHORT_TEXT_VISIBLE_CHARS = 12;
  var SHORT_TEXT_HIDE_DELAY_MS = 1500;
  var LONG_TEXT_HIDE_DELAY_MS = 4500;
  var FADE_OUT_MS = 180;
  var HOVER_RECHECK_MS = 120;
  var TranslationCard = class {
    host = null;
    shadow = null;
    content = null;
    anchor = null;
    rafId = 0;
    hideTimeoutId = 0;
    fadeTimeoutId = 0;
    hoverPollTimeoutId = 0;
    isHovered = false;
    isDismissing = false;
    currentTone = "translation";
    autoHideDelay = 0;
    show(anchor, translation, tone = "translation") {
      this.ensure();
      this.cancelHideTimers();
      this.anchor = anchor;
      this.isDismissing = false;
      this.currentTone = tone;
      this.autoHideDelay = tone === "loading" ? 0 : resolveAutoHideDelay(translation, tone);
      if (!this.host || !this.content) {
        return;
      }
      this.content.textContent = translation;
      this.content.className = `card card--${tone}`;
      this.content.classList.add("card--visible");
      this.host.hidden = false;
      this.host.style.pointerEvents = "auto";
      this.position();
      this.scheduleAutoHide();
    }
    hide() {
      this.cancelHideTimers();
      this.anchor = null;
      this.isHovered = false;
      this.isDismissing = false;
      if (this.host && this.content) {
        this.content.classList.remove("card--visible");
        this.host.style.pointerEvents = "none";
        this.host.hidden = true;
      }
    }
    repositionSoon() {
      if (!this.anchor || this.rafId) {
        return;
      }
      this.rafId = window.requestAnimationFrame(() => {
        this.rafId = 0;
        this.position();
      });
    }
    remove() {
      this.cancelHideTimers();
      this.host?.remove();
      this.host = null;
      this.shadow = null;
      this.content = null;
      this.anchor = null;
      this.isHovered = false;
      this.isDismissing = false;
    }
    ensure() {
      if (this.host && this.shadow && this.content) {
        return;
      }
      const host = document.getElementById(HOST_ID);
      this.host = host ?? document.createElement("div");
      this.host.id = HOST_ID;
      this.host.hidden = true;
      this.host.style.position = "absolute";
      this.host.style.zIndex = "2147483647";
      this.host.style.pointerEvents = "none";
      if (!host) {
        document.documentElement.append(this.host);
      }
      this.shadow = this.host.shadowRoot ?? this.host.attachShadow({ mode: "open" });
      this.shadow.replaceChildren();
      const style = document.createElement("style");
      style.textContent = `
      :host {
        all: initial;
      }

      .card {
        box-sizing: border-box;
        display: inline-block;
        min-height: 32px;
        max-height: 220px;
        overflow: auto;
        padding: 10px 12px;
        border: 1px solid rgba(20, 31, 51, 0.14);
        border-radius: 8px;
        background: #ffffff;
        box-shadow: 0 8px 24px rgba(20, 31, 51, 0.14);
        color: #141f33;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        font-size: 13px;
        line-height: 1.45;
        overflow-wrap: anywhere;
        white-space: pre-wrap;
        opacity: 0;
        transform: translateY(4px);
        transition: opacity 180ms ease, transform 180ms ease;
      }

      .card--visible {
        opacity: 1;
        transform: translateY(0);
      }

      .card--error {
        border-color: rgba(176, 52, 52, 0.28);
        background: #fff7f7;
        color: #7f1d1d;
      }

      .card--loading {
        color: #4b5563;
      }
    `;
      this.content = document.createElement("div");
      this.content.className = "card";
      this.content.addEventListener("mouseenter", this.handleMouseEnter);
      this.content.addEventListener("mouseleave", this.handleMouseLeave);
      this.shadow.append(style, this.content);
    }
    position() {
      if (!this.anchor || !this.host || this.host.hidden || !this.anchor.isConnected) {
        this.hide();
        return;
      }
      const rect = this.anchor.getBoundingClientRect();
      if (!rect.width || !rect.height) {
        this.hide();
        return;
      }
      const maxWidth = Math.min(MAX_CARD_WIDTH, window.innerWidth - VIEWPORT_PADDING * 2);
      const width = this.measureCardWidth(maxWidth);
      const left = Math.max(VIEWPORT_PADDING, Math.min(rect.left, window.innerWidth - VIEWPORT_PADDING - width));
      const spaceBelow = window.innerHeight - rect.bottom - VIEWPORT_PADDING;
      const spaceAbove = rect.top - VIEWPORT_PADDING;
      const shouldOpenAbove = spaceBelow < FLIP_ABOVE_SPACE_THRESHOLD && spaceAbove > spaceBelow;
      const maxHeight = Math.max(
        MIN_CARD_HEIGHT,
        Math.min(MAX_CARD_HEIGHT, shouldOpenAbove ? spaceAbove - CARD_GAP : spaceBelow - CARD_GAP)
      );
      this.host.style.left = `${left + window.scrollX}px`;
      this.host.style.width = `${width}px`;
      this.host.style.maxHeight = `${maxHeight}px`;
      if (this.content) {
        this.content.style.width = `${width}px`;
        this.content.style.maxWidth = `${width}px`;
        this.content.style.maxHeight = `${maxHeight}px`;
      }
      const cardHeight = this.measureCardHeight(maxHeight);
      const top = shouldOpenAbove ? Math.max(VIEWPORT_PADDING, rect.top - CARD_GAP - cardHeight) : Math.min(rect.bottom + CARD_GAP, window.innerHeight - VIEWPORT_PADDING);
      this.host.style.top = `${top + window.scrollY}px`;
    }
    measureCardWidth(maxWidth) {
      const measuredWidth = this.measureRenderedCardWidth(maxWidth);
      if (measuredWidth) {
        return measuredWidth;
      }
      return Math.min(maxWidth, estimateCardWidth(this.content?.textContent ?? ""));
    }
    measureRenderedCardWidth(maxWidth) {
      if (!this.host || !this.content) {
        return 0;
      }
      this.host.style.width = "auto";
      this.host.style.maxWidth = `${maxWidth}px`;
      this.content.style.width = "fit-content";
      this.content.style.maxWidth = `${maxWidth}px`;
      const measuredWidth = this.content.getBoundingClientRect().width || this.content.offsetWidth || this.content.scrollWidth;
      return measuredWidth ? Math.min(maxWidth, Math.ceil(measuredWidth)) : 0;
    }
    measureCardHeight(maxHeight) {
      if (!this.content) {
        return Math.min(FALLBACK_CARD_HEIGHT, maxHeight);
      }
      const measuredHeight = this.content.getBoundingClientRect().height || this.content.scrollHeight;
      return Math.min(maxHeight, measuredHeight || FALLBACK_CARD_HEIGHT);
    }
    scheduleAutoHide() {
      if (!this.autoHideDelay) {
        return;
      }
      if (this.hideTimeoutId) {
        window.clearTimeout(this.hideTimeoutId);
        this.hideTimeoutId = 0;
      }
      this.hideTimeoutId = window.setTimeout(() => {
        this.hideTimeoutId = 0;
        if (this.isDismissing || this.host?.hidden) {
          return;
        }
        if (this.isPointerInsideCard()) {
          this.isHovered = true;
          this.startHoverPolling();
          return;
        }
        this.beginFadeOut();
      }, this.autoHideDelay);
    }
    beginFadeOut() {
      if (!this.host || !this.content || this.host.hidden) {
        return;
      }
      this.isDismissing = true;
      this.isHovered = false;
      this.anchor = null;
      this.stopHoverPolling();
      this.host.style.pointerEvents = "none";
      this.content.classList.remove("card--visible");
      this.fadeTimeoutId = window.setTimeout(() => {
        this.fadeTimeoutId = 0;
        if (this.host) {
          this.host.hidden = true;
        }
      }, FADE_OUT_MS);
    }
    cancelHideTimers() {
      if (this.hideTimeoutId) {
        window.clearTimeout(this.hideTimeoutId);
        this.hideTimeoutId = 0;
      }
      if (this.fadeTimeoutId) {
        window.clearTimeout(this.fadeTimeoutId);
        this.fadeTimeoutId = 0;
      }
      if (this.hoverPollTimeoutId) {
        window.clearTimeout(this.hoverPollTimeoutId);
        this.hoverPollTimeoutId = 0;
      }
    }
    handleMouseEnter = () => {
      if (this.isDismissing || this.host?.hidden) {
        return;
      }
      this.isHovered = true;
      this.cancelHideTimers();
      this.content?.classList.add("card--visible");
    };
    handleMouseLeave = () => {
      if (this.isDismissing || this.host?.hidden) {
        return;
      }
      this.isHovered = false;
      this.stopHoverPolling();
      if (this.currentTone !== "loading") {
        this.scheduleAutoHide();
      }
    };
    startHoverPolling() {
      if (this.hoverPollTimeoutId) {
        return;
      }
      this.hoverPollTimeoutId = window.setTimeout(() => {
        this.hoverPollTimeoutId = 0;
        if (this.isPointerInsideCard()) {
          this.startHoverPolling();
          return;
        }
        this.isHovered = false;
        if (this.currentTone !== "loading") {
          this.scheduleAutoHide();
        }
      }, HOVER_RECHECK_MS);
    }
    stopHoverPolling() {
      if (this.hoverPollTimeoutId) {
        window.clearTimeout(this.hoverPollTimeoutId);
        this.hoverPollTimeoutId = 0;
      }
    }
    isPointerInsideCard() {
      return Boolean(this.host?.matches(":hover") || this.content?.matches(":hover"));
    }
  };
  function resolveAutoHideDelay(text, tone) {
    if (tone === "error") {
      return LONG_TEXT_HIDE_DELAY_MS;
    }
    const visibleChars = Array.from(text.replace(/\s+/g, "")).length;
    return visibleChars <= SHORT_TEXT_VISIBLE_CHARS ? SHORT_TEXT_HIDE_DELAY_MS : LONG_TEXT_HIDE_DELAY_MS;
  }
  function estimateCardWidth(text) {
    const widestLineWidth = Math.max(
      ...text.split(/\r?\n/).map((line) => estimateLineWidth(line)),
      APPROX_ASCII_CHAR_WIDTH * 2
    );
    return Math.ceil(widestLineWidth + CARD_HORIZONTAL_PADDING + CARD_HORIZONTAL_BORDER);
  }
  function estimateLineWidth(text) {
    let width = 0;
    for (const char of text) {
      if (/\s/.test(char)) {
        width += APPROX_SPACE_CHAR_WIDTH;
        continue;
      }
      width += isWideCharacter(char) ? APPROX_WIDE_CHAR_WIDTH : APPROX_ASCII_CHAR_WIDTH;
    }
    return width;
  }
  function isWideCharacter(char) {
    return /[^\u0000-\u00ff]/.test(char);
  }

  // src/content/editable.ts
  var SUPPORTED_INPUT_TYPES = /* @__PURE__ */ new Set(["", "text", "search"]);
  var BLOCKED_INPUT_TYPES = /* @__PURE__ */ new Set([
    "button",
    "checkbox",
    "color",
    "date",
    "datetime-local",
    "email",
    "file",
    "hidden",
    "image",
    "month",
    "number",
    "password",
    "radio",
    "range",
    "reset",
    "submit",
    "tel",
    "time",
    "url",
    "week"
  ]);
  var SENSITIVE_HINTS = [
    "2fa",
    "cardnumber",
    "card-number",
    "cc-number",
    "creditcard",
    "credit-card",
    "cvc",
    "cvv",
    "email",
    "mail",
    "one-time-code",
    "otp",
    "passcode",
    "password",
    "phone",
    "pin",
    "security-code",
    "ssn",
    "telephone",
    "verification-code"
  ];
  function resolveEditableTarget(target) {
    const element = eventTargetToElement(target);
    if (!element) {
      return null;
    }
    for (let current = element; current; current = parentElementOrHost(current)) {
      if (current instanceof HTMLInputElement || current instanceof HTMLTextAreaElement) {
        return current;
      }
      if (current instanceof HTMLElement && isEditableHost(current)) {
        return current;
      }
    }
    return null;
  }
  function resolveActiveEditableTarget(doc = document) {
    return resolveEditableTarget(deepActiveElement(doc));
  }
  function resolveSelectionEditableTarget(doc = document) {
    const selection = doc.getSelection();
    return resolveEditableTarget(selection?.anchorNode ?? selection?.focusNode ?? null);
  }
  function isEligibleEditableElement(element) {
    if (!element || !element.isConnected) {
      return false;
    }
    if (element instanceof HTMLInputElement) {
      return isEligibleInput(element);
    }
    if (element instanceof HTMLTextAreaElement) {
      return !element.disabled && !element.readOnly && isVisible(element) && !hasSensitiveHints(element);
    }
    return isEditableHost(element) && !isAriaDisabledOrReadonly(element) && isVisible(element) && !hasSensitiveHints(element);
  }
  function getEditableText(element) {
    if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
      return element.value;
    }
    return getContentEditableText(element).trim();
  }
  function hasMinimumVisibleChars(text, minChars) {
    return visibleCharCount(text) >= minChars;
  }
  function isActiveEditable(element, doc = document) {
    const activeElement = doc.activeElement;
    if (!activeElement) {
      return false;
    }
    return activeElement === element || element.contains(activeElement);
  }
  function isEligibleInput(input) {
    const type = input.type.toLowerCase();
    if (input.disabled || input.readOnly || !isVisible(input) || BLOCKED_INPUT_TYPES.has(type)) {
      return false;
    }
    if (!SUPPORTED_INPUT_TYPES.has(type)) {
      return false;
    }
    return !hasSensitiveHints(input);
  }
  function isContentEditableRoot(element) {
    const value = element.getAttribute("contenteditable")?.toLowerCase();
    return value === "" || value === "true" || value === "plaintext-only";
  }
  function isAriaTextBox(element) {
    const role = element.getAttribute("role")?.toLowerCase();
    return role === "textbox" || role === "searchbox";
  }
  function isEditableHost(element) {
    return isContentEditableRoot(element) || isAriaTextBox(element);
  }
  function isAriaDisabledOrReadonly(element) {
    return element.getAttribute("aria-disabled") === "true" || element.getAttribute("aria-readonly") === "true";
  }
  function getContentEditableText(element) {
    const text = readElementText(element);
    const rootPlaceholders = getPlaceholderValues(element);
    if (rootPlaceholders.some((placeholder) => text.trim() === placeholder)) {
      return "";
    }
    const clone = element.cloneNode(true);
    const placeholderNodes = Array.from(
      clone.querySelectorAll(
        "[aria-placeholder], [data-placeholder], [placeholder], [contenteditable='false']"
      )
    );
    for (const node of placeholderNodes) {
      const nodeText = readElementText(node).trim();
      const placeholderValues = [...getPlaceholderValues(node), ...rootPlaceholders];
      if (nodeText && (placeholderValues.includes(nodeText) || node.hasAttribute("data-placeholder") && !node.getAttribute("data-placeholder")?.trim() || hasPlaceholderClass(node))) {
        node.remove();
      }
    }
    return readElementText(clone);
  }
  function getPlaceholderValues(element) {
    return [
      element.getAttribute("aria-placeholder"),
      element.getAttribute("data-placeholder"),
      element.getAttribute("placeholder")
    ].map((value) => value?.trim()).filter((value) => Boolean(value));
  }
  function readElementText(element) {
    return (element.innerText || element.textContent || "").replace(/[\u200B\uFEFF]/g, "");
  }
  function hasPlaceholderClass(element) {
    return Array.from(element.classList).some((className) => className.toLowerCase().includes("placeholder")) || Boolean(element.querySelector("[class*='placeholder']"));
  }
  function hasSensitiveHints(element) {
    const hintText = [
      element.getAttribute("autocomplete"),
      element.getAttribute("inputmode"),
      element.getAttribute("name"),
      element.getAttribute("id"),
      element.getAttribute("aria-label"),
      element.getAttribute("placeholder"),
      element.getAttribute("title"),
      element.className
    ].filter(Boolean).join(" ").toLowerCase().replace(/\s+/g, "-");
    return SENSITIVE_HINTS.some((hint) => hintText.includes(hint));
  }
  function isVisible(element) {
    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") {
      return false;
    }
    if (element.getAttribute("aria-hidden") === "true" || element.hidden) {
      return false;
    }
    return true;
  }
  function visibleCharCount(text) {
    return Array.from(text.replace(/\s+/g, "")).length;
  }
  function eventTargetToElement(target) {
    if (target instanceof Element) {
      return target;
    }
    return target instanceof Text ? target.parentElement : null;
  }
  function parentElementOrHost(element) {
    if (element.parentElement) {
      return element.parentElement;
    }
    const root = element.getRootNode();
    return root instanceof ShadowRoot ? root.host : null;
  }
  function deepActiveElement(doc) {
    let activeElement = doc.activeElement;
    while (activeElement?.shadowRoot?.activeElement) {
      activeElement = activeElement.shadowRoot.activeElement;
    }
    return activeElement;
  }

  // src/shared/settings.ts
  var IDLE_DELAY_MIN_MS = 800;
  var IDLE_DELAY_MAX_MS = 1500;
  var IDLE_DELAY_STEP_MS = 100;
  var DEFAULT_SETTINGS = {
    enabled: true,
    sourceLanguage: "Chinese",
    targetLanguage: "English",
    providerMode: "openai-compatible",
    baseUrl: "https://api.openai.com/v1",
    model: "gpt-4o-mini",
    thinkingEnabled: false,
    apiKey: "",
    idleMs: 800,
    minChars: 2
  };
  function normalizeSettings(value) {
    const settings2 = { ...DEFAULT_SETTINGS, ...value };
    return {
      ...settings2,
      enabled: Boolean(settings2.enabled),
      sourceLanguage: nonEmpty(settings2.sourceLanguage, DEFAULT_SETTINGS.sourceLanguage),
      targetLanguage: nonEmpty(settings2.targetLanguage, DEFAULT_SETTINGS.targetLanguage),
      providerMode: "openai-compatible",
      baseUrl: trimTrailingSlash(nonEmpty(settings2.baseUrl, DEFAULT_SETTINGS.baseUrl)),
      model: nonEmpty(settings2.model, DEFAULT_SETTINGS.model),
      thinkingEnabled: Boolean(settings2.thinkingEnabled),
      apiKey: settings2.apiKey?.trim() ?? "",
      idleMs: normalizeIdleMs(settings2.idleMs),
      minChars: Math.max(1, Number(settings2.minChars) || DEFAULT_SETTINGS.minChars)
    };
  }
  async function getSettings() {
    const value = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    return normalizeSettings(value);
  }
  function nonEmpty(value, fallback) {
    const trimmed = value?.trim();
    return trimmed ? trimmed : fallback;
  }
  function trimTrailingSlash(value) {
    return value.replace(/\/+$/, "");
  }
  function normalizeIdleMs(value) {
    const numeric = Number(value) || DEFAULT_SETTINGS.idleMs;
    const clamped = Math.min(IDLE_DELAY_MAX_MS, Math.max(IDLE_DELAY_MIN_MS, numeric));
    return Math.round(clamped / IDLE_DELAY_STEP_MS) * IDLE_DELAY_STEP_MS;
  }

  // src/content.ts
  var card = new TranslationCard();
  var VISIBILITY_ATTRIBUTE_FILTER = ["aria-hidden", "aria-disabled", "aria-readonly", "class", "hidden", "style"];
  var settings = DEFAULT_SETTINGS;
  var activeEditable = null;
  var debounceId = 0;
  var requestId = 0;
  var isComposing = false;
  var visibilityObserver = null;
  var lastScheduledText = "";
  var lastScheduledElement = null;
  var lastRequestedText = "";
  var lastRequestedElement = null;
  var lastCompletedText = "";
  var lastCompletedElement = null;
  var lastPublishedText = "";
  var lastPublishedElement = null;
  void init();
  async function init() {
    const cleanupGlobal = globalThis;
    cleanupGlobal.__writeFirstCleanup__?.();
    settings = await getSettings();
    cleanupGlobal.__writeFirstCleanup__ = registerListeners();
  }
  function registerListeners() {
    document.addEventListener("focusin", handleFocusIn, true);
    document.addEventListener("focusout", handleFocusOut, true);
    document.addEventListener("beforeinput", handleBeforeInput, true);
    document.addEventListener("input", handleInput, true);
    document.addEventListener("keyup", handleKeyUp, true);
    document.addEventListener("pointerdown", handlePointerDown, true);
    document.addEventListener("mousedown", handlePointerDown, true);
    document.addEventListener("click", handlePointerDown, true);
    document.addEventListener("compositionstart", handleCompositionStart, true);
    document.addEventListener("compositionend", handleCompositionEnd, true);
    document.addEventListener("selectionchange", handleSelectionChange, true);
    window.addEventListener("scroll", handleViewportChange, true);
    window.addEventListener("resize", handleViewportChange, true);
    const handleStorageChange = (changes, areaName) => {
      if (areaName !== "sync") {
        return;
      }
      const next = { ...settings };
      for (const [key, change] of Object.entries(changes)) {
        if (key in DEFAULT_SETTINGS) {
          Object.assign(next, { [key]: change.newValue });
        }
      }
      settings = normalizeSettings(next);
      if (!settings.enabled) {
        clearPending();
        hideCardAndInvalidate();
        return;
      }
      if (activeEditable && isEligibleEditableElement(activeEditable) && isActiveEditable(activeEditable)) {
        scheduleTranslation(activeEditable);
      }
    };
    chrome.storage.onChanged.addListener(handleStorageChange);
    const observer = new MutationObserver(handleDocumentMutation);
    observer.observe(document.documentElement, {
      childList: true,
      characterData: true,
      subtree: true
    });
    return () => {
      document.removeEventListener("focusin", handleFocusIn, true);
      document.removeEventListener("focusout", handleFocusOut, true);
      document.removeEventListener("beforeinput", handleBeforeInput, true);
      document.removeEventListener("input", handleInput, true);
      document.removeEventListener("keyup", handleKeyUp, true);
      document.removeEventListener("pointerdown", handlePointerDown, true);
      document.removeEventListener("mousedown", handlePointerDown, true);
      document.removeEventListener("click", handlePointerDown, true);
      document.removeEventListener("compositionstart", handleCompositionStart, true);
      document.removeEventListener("compositionend", handleCompositionEnd, true);
      document.removeEventListener("selectionchange", handleSelectionChange, true);
      window.removeEventListener("scroll", handleViewportChange, true);
      window.removeEventListener("resize", handleViewportChange, true);
      chrome.storage.onChanged.removeListener?.(handleStorageChange);
      observer.disconnect();
      visibilityObserver?.disconnect();
      visibilityObserver = null;
      clearPending();
      card.remove();
    };
  }
  function handleFocusIn(event) {
    const target = resolveEventEditableTarget(event.target);
    const nextEditable = isEligibleEditableElement(target) ? target : null;
    if (!nextEditable) {
      if (!isDocumentShell(event.target)) {
        setActiveEditable(null);
        clearPending();
        hideCardAndInvalidate();
      }
      return;
    }
    setActiveEditable(nextEditable);
    if (!isComposing) {
      scheduleTranslation(nextEditable);
    }
  }
  function handleFocusOut(event) {
    if (activeEditable && event.target instanceof Node && activeEditable.contains(event.target)) {
      window.setTimeout(() => {
        const currentEditable = resolveActiveEditableTarget() ?? resolveSelectionEditableTarget();
        if (activeEditable && currentEditable && currentEditable !== activeEditable) {
          clearActiveEditableState();
          return;
        }
        if (activeEditable && (!activeEditable.isConnected || !isEligibleEditableElement(activeEditable) || !hasRenderableEditableBox(activeEditable))) {
          clearActiveEditableState();
        }
      }, 0);
    }
  }
  function handlePointerDown(event) {
    if (isTranslationCardTarget(event.target)) {
      return;
    }
    if (isPublishAction(event.target)) {
      suppressPublishedText(resolveEventEditableTarget(event.target) ?? activeEditable);
      clearPending();
      hideCardAndInvalidate();
      setActiveEditable(null);
      return;
    }
    if (!activeEditable || !(event.target instanceof Node) || activeEditable.contains(event.target)) {
      return;
    }
    clearPending();
    hideCardAndInvalidate();
    setActiveEditable(null);
  }
  function handleCompositionStart(event) {
    if (resolveEventEditableTarget(event.target) === activeEditable) {
      isComposing = true;
      clearPending();
      hideCardAndInvalidate();
    }
  }
  function handleCompositionEnd(event) {
    const target = resolveEventEditableTarget(event.target) ?? activeEditable;
    isComposing = false;
    if (target && isEligibleEditableElement(target)) {
      setActiveEditable(target);
      scheduleTranslation(target);
    }
  }
  function handleBeforeInput(event) {
    window.setTimeout(() => {
      refreshEditableFromCurrentContext(event.target);
    }, 0);
  }
  function handleInput(event) {
    const target = resolveEventEditableTarget(event.target);
    if (!isEligibleEditableElement(target)) {
      clearPending();
      hideCardAndInvalidate();
      setActiveEditable(null);
      return;
    }
    setActiveEditable(target);
    hideCardAndInvalidate();
    if (!isComposing) {
      scheduleTranslation(target);
    }
  }
  function handleKeyUp(event) {
    if (isComposing || event.isComposing) {
      return;
    }
    refreshEditableFromCurrentContext(event.target);
  }
  function handleSelectionChange() {
    if (isComposing) {
      return;
    }
    refreshEditableFromCurrentContext(null);
  }
  function handleViewportChange() {
    card.repositionSoon();
  }
  function scheduleTranslation(element) {
    if (!settings.enabled || !isEligibleEditableElement(element)) {
      return;
    }
    const text = getEditableText(element).trim();
    if (shouldSuppressPublishedText(element, text)) {
      return;
    }
    if (!hasMinimumVisibleChars(text, settings.minChars)) {
      return;
    }
    if (element === lastScheduledElement && text === lastScheduledText || element === lastRequestedElement && text === lastRequestedText || element === lastCompletedElement && text === lastCompletedText) {
      return;
    }
    clearPending();
    lastScheduledText = text;
    lastScheduledElement = element;
    debounceId = window.setTimeout(() => {
      void requestTranslation(element, text);
    }, settings.idleMs);
  }
  async function requestTranslation(element, text) {
    if (!settings.enabled || activeEditable !== element || !isEligibleEditableElement(element)) {
      return;
    }
    const id = ++requestId;
    lastRequestedText = text;
    lastRequestedElement = element;
    lastScheduledText = "";
    lastScheduledElement = null;
    card.show(element, "Translating...", "loading");
    let response;
    try {
      response = await chrome.runtime.sendMessage({
        type: "TRANSLATE_TEXT",
        text,
        sourceLanguage: settings.sourceLanguage,
        targetLanguage: settings.targetLanguage
      });
    } catch (error) {
      showFailureIfCurrent(id, element, text, errorMessage(error));
      return;
    }
    if (!response) {
      showFailureIfCurrent(id, element, text, "No response from the extension background worker.");
      return;
    }
    if (id !== requestId || activeEditable !== element) {
      return;
    }
    const currentText = getEditableText(element).trim();
    if (currentText !== lastRequestedText) {
      if (!hasMinimumVisibleChars(currentText, settings.minChars)) {
        clearPending();
        hideCardAndInvalidate();
      }
      return;
    }
    if (!response.ok) {
      card.show(element, `Translation failed: ${response.error}`, "error");
      return;
    }
    lastCompletedText = text;
    lastCompletedElement = element;
    card.show(element, response.translation);
    void recordExcerpt(text);
  }
  async function recordExcerpt(text) {
    try {
      await chrome.runtime.sendMessage({
        type: "RECORD_EXCERPT",
        text
      });
    } catch {
    }
  }
  function resolveEventEditableTarget(target) {
    return resolveEditableTarget(target) ?? resolveActiveEditableTarget() ?? resolveSelectionEditableTarget();
  }
  function refreshEditableFromCurrentContext(target) {
    const editable = resolveEventEditableTarget(target);
    if (!isEligibleEditableElement(editable)) {
      return;
    }
    setActiveEditable(editable);
    scheduleTranslation(editable);
  }
  function handleDocumentMutation() {
    if (!activeEditable) {
      return;
    }
    if (!activeEditable.isConnected || !isEligibleEditableElement(activeEditable)) {
      clearActiveEditableState();
      return;
    }
    if (!hasRenderableEditableBox(activeEditable)) {
      clearActiveEditableState();
      return;
    }
    syncActiveEditableVisibilityObservation();
    const currentText = getEditableText(activeEditable).trim();
    if (!hasMinimumVisibleChars(currentText, settings.minChars)) {
      clearPending();
      hideCardAndInvalidate();
    }
  }
  function isDocumentShell(target) {
    return target === document.body || target === document.documentElement;
  }
  function isPublishAction(target) {
    const element = eventTargetToElement2(target);
    const action = element?.closest(
      'button, [role="button"], [data-testid="tweetButton"], [data-testid="tweetButtonInline"]'
    );
    if (!action) {
      return false;
    }
    const testId = action.getAttribute("data-testid");
    if (testId === "tweetButton" || testId === "tweetButtonInline") {
      return true;
    }
    const label = [
      action.getAttribute("aria-label"),
      action.getAttribute("data-testid"),
      action.getAttribute("title"),
      action.textContent
    ].filter(Boolean).join(" ").trim().toLowerCase();
    return /post|tweet|reply/.test(label);
  }
  function eventTargetToElement2(target) {
    if (target instanceof Element) {
      return target;
    }
    return target instanceof Text ? target.parentElement : null;
  }
  function isTranslationCardTarget(target) {
    const element = eventTargetToElement2(target);
    return element?.id === "write-first-translation-card-host";
  }
  function showFailureIfCurrent(id, element, text, message) {
    if (id !== requestId || activeEditable !== element || getEditableText(element).trim() !== text) {
      return;
    }
    card.show(element, `Translation failed: ${message}`, "error");
  }
  function errorMessage(error) {
    return error instanceof Error ? error.message : "Unknown error.";
  }
  function clearPending() {
    if (debounceId) {
      window.clearTimeout(debounceId);
      debounceId = 0;
    }
  }
  function clearActiveEditableState() {
    clearPending();
    hideCardAndInvalidate();
    setActiveEditable(null);
  }
  function hasRenderableEditableBox(element) {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  function setActiveEditable(element) {
    activeEditable = element;
    syncActiveEditableVisibilityObservation();
  }
  function syncActiveEditableVisibilityObservation() {
    visibilityObserver?.disconnect();
    if (!activeEditable) {
      return;
    }
    visibilityObserver ??= new MutationObserver(handleActiveEditableVisibilityMutation);
    for (let current = activeEditable; current; current = current.parentElement) {
      visibilityObserver.observe(current, {
        attributes: true,
        attributeFilter: VISIBILITY_ATTRIBUTE_FILTER
      });
      if (current === document.documentElement) {
        break;
      }
    }
  }
  function handleActiveEditableVisibilityMutation() {
    if (!activeEditable) {
      return;
    }
    if (!activeEditable.isConnected || !isEligibleEditableElement(activeEditable) || !hasRenderableEditableBox(activeEditable)) {
      clearActiveEditableState();
    }
  }
  function suppressPublishedText(element) {
    if (!element || !isEligibleEditableElement(element)) {
      clearPublishedTextSuppression();
      return;
    }
    lastPublishedText = getEditableText(element).trim();
    lastPublishedElement = lastPublishedText ? element : null;
  }
  function shouldSuppressPublishedText(element, text) {
    if (!lastPublishedElement || !lastPublishedText) {
      return false;
    }
    if (!lastPublishedElement.isConnected || element !== lastPublishedElement || text !== lastPublishedText) {
      clearPublishedTextSuppression();
      return false;
    }
    return true;
  }
  function clearPublishedTextSuppression() {
    lastPublishedText = "";
    lastPublishedElement = null;
  }
  function hideCardAndInvalidate() {
    requestId += 1;
    lastScheduledText = "";
    lastScheduledElement = null;
    lastRequestedText = "";
    lastRequestedElement = null;
    lastCompletedText = "";
    lastCompletedElement = null;
    card.hide();
  }
})();
//# sourceMappingURL=content.js.map
