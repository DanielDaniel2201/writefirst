"use strict";
(() => {
  // src/background/openaiCompatible.ts
  function buildTranslationRequest(settings, text, sourceLanguage, targetLanguage) {
    const endpoint = chatCompletionsEndpoint(settings.baseUrl);
    const body = {
      model: settings.model,
      temperature: 0.2,
      messages: [
        {
          role: "system",
          content: `You translate user-provided text for language learning. Return only a natural translation in ${targetLanguage}. Do not include explanations, alternatives, quotation marks, or notes.`
        },
        {
          role: "user",
          content: `Translate from ${sourceLanguage} to ${targetLanguage}:

${text}`
        }
      ]
    };
    if (settings.thinkingEnabled) {
      Object.assign(body, { thinking: { type: "enabled" } });
    }
    return {
      url: endpoint,
      init: {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.apiKey}`
        },
        body: JSON.stringify(body)
      }
    };
  }
  async function translateWithOpenAICompatible(settings, text, sourceLanguage, targetLanguage) {
    if (!settings.apiKey) {
      throw new Error("API key is not configured.");
    }
    const request = buildTranslationRequest(settings, text, sourceLanguage, targetLanguage);
    const response = await fetch(request.url, request.init);
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(payload.error?.message || `Translation request failed with ${response.status}.`);
    }
    return extractTranslation(payload);
  }
  function extractTranslation(payload) {
    const translation = payload.choices?.[0]?.message?.content?.trim();
    if (!translation) {
      throw new Error("Translation response did not include text.");
    }
    return translation;
  }
  function chatCompletionsEndpoint(baseUrl) {
    const normalized = baseUrl.replace(/\/+$/, "");
    return normalized.endsWith("/chat/completions") ? normalized : `${normalized}/chat/completions`;
  }

  // src/shared/excerpts.ts
  var EXCERPTS_STORAGE_KEY = "excerpts";
  var writeQueue = Promise.resolve();
  async function getExcerpts() {
    const value = await chrome.storage.local.get(EXCERPTS_STORAGE_KEY);
    return normalizeExcerpts(value[EXCERPTS_STORAGE_KEY]);
  }
  function addExcerpt(text, now = /* @__PURE__ */ new Date()) {
    const normalizedText = text.trim();
    if (!normalizedText) {
      return Promise.resolve();
    }
    writeQueue = writeQueue.catch(() => void 0).then(async () => {
      const excerpts = await getExcerpts();
      excerpts.push({
        text: normalizedText,
        createdAt: now.toISOString()
      });
      await chrome.storage.local.set({ [EXCERPTS_STORAGE_KEY]: excerpts });
    });
    return writeQueue;
  }
  function normalizeExcerpts(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.filter(isExcerpt).map((excerpt) => ({
      text: excerpt.text,
      createdAt: excerpt.createdAt
    }));
  }
  function isExcerpt(value) {
    if (!value || typeof value !== "object") {
      return false;
    }
    const excerpt = value;
    return typeof excerpt.text === "string" && excerpt.text.trim().length > 0 && typeof excerpt.createdAt === "string" && !Number.isNaN(Date.parse(excerpt.createdAt));
  }

  // src/shared/settings.ts
  var IDLE_DELAY_MIN_MS = 800;
  var IDLE_DELAY_MAX_MS = 1500;
  var IDLE_DELAY_STEP_MS = 100;
  var DEFAULT_SETTINGS = {
    enabled: true,
    sourceLanguage: "Chinese",
    targetLanguage: "English",
    providerMode: "openai-compatible",
    baseUrl: "https://api.openai.com/v1",
    model: "gpt-4o-mini",
    thinkingEnabled: false,
    apiKey: "",
    idleMs: 800,
    minChars: 2
  };
  function normalizeSettings(value) {
    const settings = { ...DEFAULT_SETTINGS, ...value };
    return {
      ...settings,
      enabled: Boolean(settings.enabled),
      sourceLanguage: nonEmpty(settings.sourceLanguage, DEFAULT_SETTINGS.sourceLanguage),
      targetLanguage: nonEmpty(settings.targetLanguage, DEFAULT_SETTINGS.targetLanguage),
      providerMode: "openai-compatible",
      baseUrl: trimTrailingSlash(nonEmpty(settings.baseUrl, DEFAULT_SETTINGS.baseUrl)),
      model: nonEmpty(settings.model, DEFAULT_SETTINGS.model),
      thinkingEnabled: Boolean(settings.thinkingEnabled),
      apiKey: settings.apiKey?.trim() ?? "",
      idleMs: normalizeIdleMs(settings.idleMs),
      minChars: Math.max(1, Number(settings.minChars) || DEFAULT_SETTINGS.minChars)
    };
  }
  async function getSettings() {
    const value = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    return normalizeSettings(value);
  }
  function nonEmpty(value, fallback) {
    const trimmed = value?.trim();
    return trimmed ? trimmed : fallback;
  }
  function trimTrailingSlash(value) {
    return value.replace(/\/+$/, "");
  }
  function normalizeIdleMs(value) {
    const numeric = Number(value) || DEFAULT_SETTINGS.idleMs;
    const clamped = Math.min(IDLE_DELAY_MAX_MS, Math.max(IDLE_DELAY_MIN_MS, numeric));
    return Math.round(clamped / IDLE_DELAY_STEP_MS) * IDLE_DELAY_STEP_MS;
  }

  // src/background.ts
  void chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
  chrome.action.onClicked.addListener(() => {
    void chrome.runtime.openOptionsPage();
  });
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      if (message.type === "RECORD_EXCERPT") {
        void addExcerpt(message.text).then(() => sendResponse({ ok: true })).catch((error) => {
          const message2 = error instanceof Error ? error.message : "Could not save excerpt.";
          sendResponse({ ok: false, error: message2 });
        });
        return true;
      }
      void handleTranslate(message).then((translation) => sendResponse({ ok: true, translation })).catch((error) => {
        const message2 = error instanceof Error ? error.message : "Translation failed.";
        sendResponse({ ok: false, error: message2 });
      });
      return true;
    }
  );
  async function handleTranslate(message) {
    const settings = await getSettings();
    if (!settings.enabled) {
      throw new Error("Extension is disabled.");
    }
    const text = message.text.trim();
    if (!text) {
      throw new Error("No text to translate.");
    }
    return translateWithOpenAICompatible(settings, text, message.sourceLanguage, message.targetLanguage);
  }
})();
//# sourceMappingURL=background.js.map
