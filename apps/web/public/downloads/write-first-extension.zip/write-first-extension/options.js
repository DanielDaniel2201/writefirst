"use strict";
(() => {
  // src/shared/excerpts.ts
  var EXCERPTS_STORAGE_KEY = "excerpts";
  var writeQueue = Promise.resolve();
  async function getExcerpts() {
    const value = await chrome.storage.local.get(EXCERPTS_STORAGE_KEY);
    return normalizeExcerpts(value[EXCERPTS_STORAGE_KEY]);
  }
  function normalizeExcerpts(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.filter(isExcerpt).map((excerpt) => ({
      text: excerpt.text,
      createdAt: excerpt.createdAt
    }));
  }
  function isExcerpt(value) {
    if (!value || typeof value !== "object") {
      return false;
    }
    const excerpt = value;
    return typeof excerpt.text === "string" && excerpt.text.trim().length > 0 && typeof excerpt.createdAt === "string" && !Number.isNaN(Date.parse(excerpt.createdAt));
  }

  // src/options/pagination.ts
  function getPageCount(itemCount, pageSize) {
    if (pageSize <= 0) {
      return 0;
    }
    return Math.ceil(Math.max(0, itemCount) / pageSize);
  }
  function getPageItems(items, page, pageSize) {
    if (pageSize <= 0) {
      return [];
    }
    const safePage = Math.max(1, Math.floor(page));
    const start = (safePage - 1) * pageSize;
    return items.slice(start, start + pageSize);
  }
  function getPaginationItems(currentPage2, pageCount) {
    if (pageCount <= 0) {
      return [];
    }
    if (pageCount <= 7) {
      return Array.from({ length: pageCount }, (_, index) => index + 1);
    }
    const safeCurrentPage = Math.min(pageCount, Math.max(1, Math.floor(currentPage2)));
    const visiblePages = /* @__PURE__ */ new Set([1, pageCount, safeCurrentPage - 1, safeCurrentPage, safeCurrentPage + 1]);
    const pages = [...visiblePages].filter((page) => page >= 1 && page <= pageCount).sort((a, b) => a - b);
    const result = [];
    for (const page of pages) {
      const previous = result[result.length - 1];
      if (typeof previous === "number" && page - previous > 1) {
        result.push("ellipsis");
      }
      result.push(page);
    }
    return result;
  }

  // src/shared/settings.ts
  var IDLE_DELAY_MIN_MS = 800;
  var IDLE_DELAY_MAX_MS = 1500;
  var IDLE_DELAY_STEP_MS = 100;
  var DEFAULT_SETTINGS = {
    enabled: true,
    sourceLanguage: "Chinese",
    targetLanguage: "English",
    providerMode: "openai-compatible",
    baseUrl: "https://api.openai.com/v1",
    model: "gpt-4o-mini",
    thinkingEnabled: false,
    apiKey: "",
    idleMs: 800,
    minChars: 2
  };
  function normalizeSettings(value) {
    const settings = { ...DEFAULT_SETTINGS, ...value };
    return {
      ...settings,
      enabled: Boolean(settings.enabled),
      sourceLanguage: nonEmpty(settings.sourceLanguage, DEFAULT_SETTINGS.sourceLanguage),
      targetLanguage: nonEmpty(settings.targetLanguage, DEFAULT_SETTINGS.targetLanguage),
      providerMode: "openai-compatible",
      baseUrl: trimTrailingSlash(nonEmpty(settings.baseUrl, DEFAULT_SETTINGS.baseUrl)),
      model: nonEmpty(settings.model, DEFAULT_SETTINGS.model),
      thinkingEnabled: Boolean(settings.thinkingEnabled),
      apiKey: settings.apiKey?.trim() ?? "",
      idleMs: normalizeIdleMs(settings.idleMs),
      minChars: Math.max(1, Number(settings.minChars) || DEFAULT_SETTINGS.minChars)
    };
  }
  async function getSettings() {
    const value = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    return normalizeSettings(value);
  }
  async function saveSettings(settings) {
    await chrome.storage.sync.set(normalizeSettings(settings));
  }
  function nonEmpty(value, fallback) {
    const trimmed = value?.trim();
    return trimmed ? trimmed : fallback;
  }
  function trimTrailingSlash(value) {
    return value.replace(/\/+$/, "");
  }
  function normalizeIdleMs(value) {
    const numeric = Number(value) || DEFAULT_SETTINGS.idleMs;
    const clamped = Math.min(IDLE_DELAY_MAX_MS, Math.max(IDLE_DELAY_MIN_MS, numeric));
    return Math.round(clamped / IDLE_DELAY_STEP_MS) * IDLE_DELAY_STEP_MS;
  }

  // src/options.ts
  var form = document.getElementById("settings-form");
  var enabled = document.getElementById("enabled");
  var sourceLanguage = document.getElementById("sourceLanguage");
  var targetLanguage = document.getElementById("targetLanguage");
  var idleDelay = document.getElementById("idleDelay");
  var idleDelayValue = document.getElementById("idleDelayValue");
  var baseUrl = document.getElementById("baseUrl");
  var model = document.getElementById("model");
  var thinkingEnabled = document.getElementById("thinkingEnabled");
  var apiKey = document.getElementById("apiKey");
  var status = document.getElementById("status");
  var excerptList = document.getElementById("excerpt-list");
  var excerptCount = document.getElementById("excerpt-count");
  var excerptTable = document.getElementById("excerpt-table");
  var emptyState = document.getElementById("empty-state");
  var pagination = document.getElementById("pagination");
  var navItems = Array.from(document.querySelectorAll("[data-view]"));
  var panels = Array.from(document.querySelectorAll("[data-panel]"));
  var PAGE_SIZE = 10;
  var excerpts = normalizeExcerpts([]);
  var currentPage = 1;
  idleDelay.min = String(IDLE_DELAY_MIN_MS);
  idleDelay.max = String(IDLE_DELAY_MAX_MS);
  idleDelay.step = String(IDLE_DELAY_STEP_MS);
  void hydrate();
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    void persist();
  });
  enabled.addEventListener("change", () => {
    void persist("\u5DF2\u4FDD\u5B58");
  });
  idleDelay.addEventListener("input", () => {
    updateIdleDelayValue(Number(idleDelay.value));
  });
  idleDelay.addEventListener("change", () => {
    void persist("\u5DF2\u4FDD\u5B58");
  });
  for (const navItem of navItems) {
    navItem.addEventListener("click", () => showView(navItem.dataset.view ?? "excerpts"));
  }
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && EXCERPTS_STORAGE_KEY in changes) {
      currentPage = 1;
      setExcerpts(changes[EXCERPTS_STORAGE_KEY].newValue);
    }
  });
  async function hydrate() {
    const [settings, excerpts2] = await Promise.all([getSettings(), getExcerpts()]);
    applySettings(settings);
    setExcerpts(excerpts2);
    showView(location.hash === "#settings" ? "settings" : "excerpts");
  }
  async function persist(message = "\u8BBE\u7F6E\u5DF2\u4FDD\u5B58") {
    const settings = normalizeSettings({
      ...DEFAULT_SETTINGS,
      enabled: enabled.checked,
      sourceLanguage: sourceLanguage.value,
      targetLanguage: targetLanguage.value,
      idleMs: Number(idleDelay.value),
      baseUrl: baseUrl.value,
      model: model.value,
      thinkingEnabled: thinkingEnabled.checked,
      apiKey: apiKey.value
    });
    await saveSettings(settings);
    applySettings(settings);
    setStatus(message);
  }
  function applySettings(settings) {
    enabled.checked = settings.enabled;
    sourceLanguage.value = settings.sourceLanguage;
    targetLanguage.value = settings.targetLanguage;
    idleDelay.value = String(settings.idleMs);
    updateIdleDelayValue(settings.idleMs);
    baseUrl.value = settings.baseUrl;
    model.value = settings.model;
    thinkingEnabled.checked = settings.thinkingEnabled;
    apiKey.value = settings.apiKey;
  }
  function showView(viewName) {
    const activeView = viewName === "settings" ? "settings" : "excerpts";
    for (const navItem of navItems) {
      const isActive = navItem.dataset.view === activeView;
      navItem.classList.toggle("is-active", isActive);
      navItem.setAttribute("aria-current", isActive ? "page" : "false");
    }
    for (const panel of panels) {
      panel.hidden = panel.dataset.panel !== activeView;
    }
    history.replaceState(null, "", `#${activeView}`);
  }
  function setExcerpts(value) {
    excerpts = normalizeExcerpts(value).reverse();
    currentPage = Math.min(currentPage, Math.max(1, getPageCount(excerpts.length, PAGE_SIZE)));
    renderExcerpts();
  }
  function renderExcerpts() {
    excerptCount.textContent = String(excerpts.length);
    excerptList.replaceChildren();
    const hasExcerpts = excerpts.length > 0;
    emptyState.hidden = hasExcerpts;
    excerptTable.hidden = !hasExcerpts;
    for (const excerpt of getPageItems(excerpts, currentPage, PAGE_SIZE)) {
      const row = document.createElement("tr");
      const timeCell = document.createElement("td");
      const time = document.createElement("time");
      time.dateTime = excerpt.createdAt;
      time.textContent = formatTimestamp(excerpt.createdAt);
      timeCell.append(time);
      const textCell = document.createElement("td");
      textCell.textContent = excerpt.text;
      row.append(timeCell, textCell);
      excerptList.append(row);
    }
    renderPagination();
  }
  function renderPagination() {
    const pageCount = getPageCount(excerpts.length, PAGE_SIZE);
    pagination.replaceChildren();
    pagination.hidden = pageCount <= 1;
    if (pageCount <= 1) {
      return;
    }
    for (const item of getPaginationItems(currentPage, pageCount)) {
      if (item === "ellipsis") {
        const ellipsis = document.createElement("span");
        ellipsis.className = "pagination__ellipsis";
        ellipsis.textContent = "\u2026";
        pagination.append(ellipsis);
        continue;
      }
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = String(item);
      button.setAttribute("aria-label", `\u7B2C ${item} \u9875`);
      if (item === currentPage) {
        button.className = "is-active";
        button.setAttribute("aria-current", "page");
      }
      button.addEventListener("click", () => {
        currentPage = item;
        renderExcerpts();
        excerptTable.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      pagination.append(button);
    }
  }
  function formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    if (Number.isNaN(date.getTime())) {
      return timestamp;
    }
    return new Intl.DateTimeFormat("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).format(date);
  }
  function updateIdleDelayValue(valueMs) {
    idleDelayValue.value = `${(valueMs / 1e3).toFixed(1)} \u79D2`;
  }
  function setStatus(message) {
    status.textContent = message;
    window.setTimeout(() => {
      if (status.textContent === message) {
        status.textContent = "";
      }
    }, 1800);
  }
})();
//# sourceMappingURL=options.js.map
